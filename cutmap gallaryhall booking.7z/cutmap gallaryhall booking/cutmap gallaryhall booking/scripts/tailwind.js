tailwind.config = {
  theme: {
    extend: {
      colors: {
        hoverBg: '#16a34a',
        secondaryHoverBg: '#dcfce7',
        glassWhite: '#ffffffa0',
        paymentReqPrimaryClr:'#16a34a',
        paymentReqSecondaryClr:'#dcfce7',

      }
    }
  }
}